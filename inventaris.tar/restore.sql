--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.1
-- Dumped by pg_dump version 10.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.territories DROP CONSTRAINT fk_territories_region;
ALTER TABLE ONLY public.products DROP CONSTRAINT fk_products_suppliers;
ALTER TABLE ONLY public.products DROP CONSTRAINT fk_products_categories;
ALTER TABLE ONLY public.orders DROP CONSTRAINT fk_orders_shippers;
ALTER TABLE ONLY public.orders DROP CONSTRAINT fk_orders_employees;
ALTER TABLE ONLY public.orders DROP CONSTRAINT fk_orders_customers;
ALTER TABLE ONLY public.order_details DROP CONSTRAINT fk_order_details_products;
ALTER TABLE ONLY public.order_details DROP CONSTRAINT fk_order_details_orders;
ALTER TABLE ONLY public.employees DROP CONSTRAINT fk_employees_employees;
ALTER TABLE ONLY public.employee_territories DROP CONSTRAINT fk_employee_territories_territories;
ALTER TABLE ONLY public.employee_territories DROP CONSTRAINT fk_employee_territories_employees;
ALTER TABLE ONLY public.customer_customer_demo DROP CONSTRAINT fk_customer_customer_demo_customers;
ALTER TABLE ONLY public.customer_customer_demo DROP CONSTRAINT fk_customer_customer_demo_customer_demographics;
ALTER TABLE ONLY public.tb_level DROP CONSTRAINT tb_level_pkey;
ALTER TABLE ONLY public.ruang DROP CONSTRAINT ruang_pkey;
ALTER TABLE ONLY public.us_states DROP CONSTRAINT pk_usstates;
ALTER TABLE ONLY public.territories DROP CONSTRAINT pk_territories;
ALTER TABLE ONLY public.suppliers DROP CONSTRAINT pk_suppliers;
ALTER TABLE ONLY public.shippers DROP CONSTRAINT pk_shippers;
ALTER TABLE ONLY public.region DROP CONSTRAINT pk_region;
ALTER TABLE ONLY public.products DROP CONSTRAINT pk_products;
ALTER TABLE ONLY public.orders DROP CONSTRAINT pk_orders;
ALTER TABLE ONLY public.order_details DROP CONSTRAINT pk_order_details;
ALTER TABLE ONLY public.employees DROP CONSTRAINT pk_employees;
ALTER TABLE ONLY public.employee_territories DROP CONSTRAINT pk_employee_territories;
ALTER TABLE ONLY public.customers DROP CONSTRAINT pk_customers;
ALTER TABLE ONLY public.customer_demographics DROP CONSTRAINT pk_customer_demographics;
ALTER TABLE ONLY public.customer_customer_demo DROP CONSTRAINT pk_customer_customer_demo;
ALTER TABLE ONLY public.categories DROP CONSTRAINT pk_categories;
ALTER TABLE ONLY public.petugas DROP CONSTRAINT petugas_pkey;
ALTER TABLE ONLY public.peminjaman DROP CONSTRAINT peminjaman_pkey;
ALTER TABLE ONLY public.pegawai DROP CONSTRAINT pegawai_pkey;
ALTER TABLE ONLY public.jenis DROP CONSTRAINT jenis_pkey;
ALTER TABLE ONLY public.inventaris DROP CONSTRAINT inventaris_pkey;
ALTER TABLE ONLY public.detail_pinjam DROP CONSTRAINT detail_pinjam_pkey;
ALTER TABLE public.tb_level ALTER COLUMN id_level DROP DEFAULT;
ALTER TABLE public.ruang ALTER COLUMN id_ruang DROP DEFAULT;
ALTER TABLE public.petugas ALTER COLUMN id_petugas DROP DEFAULT;
ALTER TABLE public.peminjaman ALTER COLUMN id_peminjaman DROP DEFAULT;
ALTER TABLE public.pegawai ALTER COLUMN id_pegawai DROP DEFAULT;
ALTER TABLE public.jenis ALTER COLUMN id_jenis DROP DEFAULT;
ALTER TABLE public.inventaris ALTER COLUMN id_inventaris DROP DEFAULT;
ALTER TABLE public.detail_pinjam ALTER COLUMN id_detail_pinjam DROP DEFAULT;
DROP TABLE public.us_states;
DROP TABLE public.territories;
DROP SEQUENCE public.tb_level_id_level_seq;
DROP TABLE public.tb_level;
DROP TABLE public.suppliers;
DROP TABLE public.shippers;
DROP SEQUENCE public.ruang_id_ruang_seq;
DROP TABLE public.ruang;
DROP TABLE public.region;
DROP TABLE public.products;
DROP SEQUENCE public.petugas_id_petugas_seq;
DROP TABLE public.petugas;
DROP SEQUENCE public.peminjaman_id_peminjaman_seq;
DROP TABLE public.peminjaman;
DROP SEQUENCE public.pegawai_id_pegawai_seq;
DROP TABLE public.pegawai;
DROP TABLE public.orders;
DROP TABLE public.order_details;
DROP SEQUENCE public.jenis_id_jenis_seq;
DROP TABLE public.jenis;
DROP SEQUENCE public.inventaris_id_inventaris_seq;
DROP TABLE public.inventaris;
DROP TABLE public.employees;
DROP TABLE public.employee_territories;
DROP SEQUENCE public.detail_pinjam_id_detail_pinjam_seq;
DROP TABLE public.detail_pinjam;
DROP TABLE public.customers;
DROP TABLE public.customer_demographics;
DROP TABLE public.customer_customer_demo;
DROP TABLE public.categories;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE categories (
    category_id smallint NOT NULL,
    category_name character varying(15) NOT NULL,
    description text,
    picture bytea
);


ALTER TABLE categories OWNER TO postgres;

--
-- Name: customer_customer_demo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE customer_customer_demo (
    customer_id bpchar NOT NULL,
    customer_type_id bpchar NOT NULL
);


ALTER TABLE customer_customer_demo OWNER TO postgres;

--
-- Name: customer_demographics; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE customer_demographics (
    customer_type_id bpchar NOT NULL,
    customer_desc text
);


ALTER TABLE customer_demographics OWNER TO postgres;

--
-- Name: customers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE customers (
    customer_id bpchar NOT NULL,
    company_name character varying(40) NOT NULL,
    contact_name character varying(30),
    contact_title character varying(30),
    address character varying(60),
    city character varying(15),
    region character varying(15),
    postal_code character varying(10),
    country character varying(15),
    phone character varying(24),
    fax character varying(24)
);


ALTER TABLE customers OWNER TO postgres;

--
-- Name: detail_pinjam; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE detail_pinjam (
    id_detail_pinjam integer NOT NULL,
    id_inventaris integer,
    jumlah integer
);


ALTER TABLE detail_pinjam OWNER TO postgres;

--
-- Name: detail_pinjam_id_detail_pinjam_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE detail_pinjam_id_detail_pinjam_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE detail_pinjam_id_detail_pinjam_seq OWNER TO postgres;

--
-- Name: detail_pinjam_id_detail_pinjam_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE detail_pinjam_id_detail_pinjam_seq OWNED BY detail_pinjam.id_detail_pinjam;


--
-- Name: employee_territories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE employee_territories (
    employee_id smallint NOT NULL,
    territory_id character varying(20) NOT NULL
);


ALTER TABLE employee_territories OWNER TO postgres;

--
-- Name: employees; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE employees (
    employee_id smallint NOT NULL,
    last_name character varying(20) NOT NULL,
    first_name character varying(10) NOT NULL,
    title character varying(30),
    title_of_courtesy character varying(25),
    birth_date date,
    hire_date date,
    address character varying(60),
    city character varying(15),
    region character varying(15),
    postal_code character varying(10),
    country character varying(15),
    home_phone character varying(24),
    extension character varying(4),
    photo bytea,
    notes text,
    reports_to smallint,
    photo_path character varying(255)
);


ALTER TABLE employees OWNER TO postgres;

--
-- Name: inventaris; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE inventaris (
    id_inventaris integer NOT NULL,
    nama character varying(100),
    kondisi character varying(10),
    keterangan character(10),
    jumlah integer,
    id_jenis integer,
    tanggal_register date,
    id_ruang integer,
    kode_inventaris character varying(20),
    id_petugas integer
);


ALTER TABLE inventaris OWNER TO postgres;

--
-- Name: inventaris_id_inventaris_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE inventaris_id_inventaris_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE inventaris_id_inventaris_seq OWNER TO postgres;

--
-- Name: inventaris_id_inventaris_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE inventaris_id_inventaris_seq OWNED BY inventaris.id_inventaris;


--
-- Name: jenis; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE jenis (
    id_jenis integer NOT NULL,
    nama_jenis character varying(100),
    kode_jenis character varying(10),
    keterangan character(10)
);


ALTER TABLE jenis OWNER TO postgres;

--
-- Name: jenis_id_jenis_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE jenis_id_jenis_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE jenis_id_jenis_seq OWNER TO postgres;

--
-- Name: jenis_id_jenis_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE jenis_id_jenis_seq OWNED BY jenis.id_jenis;


--
-- Name: order_details; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE order_details (
    order_id smallint NOT NULL,
    product_id smallint NOT NULL,
    unit_price real NOT NULL,
    quantity smallint NOT NULL,
    discount real NOT NULL
);


ALTER TABLE order_details OWNER TO postgres;

--
-- Name: orders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE orders (
    order_id smallint NOT NULL,
    customer_id bpchar,
    employee_id smallint,
    order_date date,
    required_date date,
    shipped_date date,
    ship_via smallint,
    freight real,
    ship_name character varying(40),
    ship_address character varying(60),
    ship_city character varying(15),
    ship_region character varying(15),
    ship_postal_code character varying(10),
    ship_country character varying(15)
);


ALTER TABLE orders OWNER TO postgres;

--
-- Name: pegawai; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE pegawai (
    id_pegawai integer NOT NULL,
    nama_pegawai character varying(100),
    nip integer,
    alamat text
);


ALTER TABLE pegawai OWNER TO postgres;

--
-- Name: pegawai_id_pegawai_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE pegawai_id_pegawai_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE pegawai_id_pegawai_seq OWNER TO postgres;

--
-- Name: pegawai_id_pegawai_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE pegawai_id_pegawai_seq OWNED BY pegawai.id_pegawai;


--
-- Name: peminjaman; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE peminjaman (
    id_peminjaman integer NOT NULL,
    tanggal_pinjam date,
    tanggal_kembali date,
    status_peminjaman character(10),
    id_pegawai integer
);


ALTER TABLE peminjaman OWNER TO postgres;

--
-- Name: peminjaman_id_peminjaman_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE peminjaman_id_peminjaman_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE peminjaman_id_peminjaman_seq OWNER TO postgres;

--
-- Name: peminjaman_id_peminjaman_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE peminjaman_id_peminjaman_seq OWNED BY peminjaman.id_peminjaman;


--
-- Name: petugas; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE petugas (
    id_petugas integer NOT NULL,
    username character varying(100),
    password character varying(100),
    nama_petugas character varying(100),
    id_level integer
);


ALTER TABLE petugas OWNER TO postgres;

--
-- Name: petugas_id_petugas_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE petugas_id_petugas_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE petugas_id_petugas_seq OWNER TO postgres;

--
-- Name: petugas_id_petugas_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE petugas_id_petugas_seq OWNED BY petugas.id_petugas;


--
-- Name: products; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE products (
    product_id smallint NOT NULL,
    product_name character varying(40) NOT NULL,
    supplier_id smallint,
    category_id smallint,
    quantity_per_unit character varying(20),
    unit_price real,
    units_in_stock smallint,
    units_on_order smallint,
    reorder_level smallint,
    discontinued integer NOT NULL
);


ALTER TABLE products OWNER TO postgres;

--
-- Name: region; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE region (
    region_id smallint NOT NULL,
    region_description bpchar NOT NULL
);


ALTER TABLE region OWNER TO postgres;

--
-- Name: ruang; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE ruang (
    id_ruang integer NOT NULL,
    nama_ruang character varying(100),
    kode_ruang character varying(20),
    keterangan character(10)
);


ALTER TABLE ruang OWNER TO postgres;

--
-- Name: ruang_id_ruang_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ruang_id_ruang_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ruang_id_ruang_seq OWNER TO postgres;

--
-- Name: ruang_id_ruang_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ruang_id_ruang_seq OWNED BY ruang.id_ruang;


--
-- Name: shippers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE shippers (
    shipper_id smallint NOT NULL,
    company_name character varying(40) NOT NULL,
    phone character varying(24)
);


ALTER TABLE shippers OWNER TO postgres;

--
-- Name: suppliers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE suppliers (
    supplier_id smallint NOT NULL,
    company_name character varying(40) NOT NULL,
    contact_name character varying(30),
    contact_title character varying(30),
    address character varying(60),
    city character varying(15),
    region character varying(15),
    postal_code character varying(10),
    country character varying(15),
    phone character varying(24),
    fax character varying(24),
    homepage text
);


ALTER TABLE suppliers OWNER TO postgres;

--
-- Name: tb_level; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_level (
    id_level integer NOT NULL,
    nama_level character varying(100)
);


ALTER TABLE tb_level OWNER TO postgres;

--
-- Name: tb_level_id_level_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE tb_level_id_level_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE tb_level_id_level_seq OWNER TO postgres;

--
-- Name: tb_level_id_level_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE tb_level_id_level_seq OWNED BY tb_level.id_level;


--
-- Name: territories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE territories (
    territory_id character varying(20) NOT NULL,
    territory_description bpchar NOT NULL,
    region_id smallint NOT NULL
);


ALTER TABLE territories OWNER TO postgres;

--
-- Name: us_states; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE us_states (
    state_id smallint NOT NULL,
    state_name character varying(100),
    state_abbr character varying(2),
    state_region character varying(50)
);


ALTER TABLE us_states OWNER TO postgres;

--
-- Name: detail_pinjam id_detail_pinjam; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY detail_pinjam ALTER COLUMN id_detail_pinjam SET DEFAULT nextval('detail_pinjam_id_detail_pinjam_seq'::regclass);


--
-- Name: inventaris id_inventaris; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY inventaris ALTER COLUMN id_inventaris SET DEFAULT nextval('inventaris_id_inventaris_seq'::regclass);


--
-- Name: jenis id_jenis; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY jenis ALTER COLUMN id_jenis SET DEFAULT nextval('jenis_id_jenis_seq'::regclass);


--
-- Name: pegawai id_pegawai; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY pegawai ALTER COLUMN id_pegawai SET DEFAULT nextval('pegawai_id_pegawai_seq'::regclass);


--
-- Name: peminjaman id_peminjaman; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY peminjaman ALTER COLUMN id_peminjaman SET DEFAULT nextval('peminjaman_id_peminjaman_seq'::regclass);


--
-- Name: petugas id_petugas; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY petugas ALTER COLUMN id_petugas SET DEFAULT nextval('petugas_id_petugas_seq'::regclass);


--
-- Name: ruang id_ruang; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ruang ALTER COLUMN id_ruang SET DEFAULT nextval('ruang_id_ruang_seq'::regclass);


--
-- Name: tb_level id_level; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_level ALTER COLUMN id_level SET DEFAULT nextval('tb_level_id_level_seq'::regclass);


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY categories (category_id, category_name, description, picture) FROM stdin;
\.
COPY categories (category_id, category_name, description, picture) FROM '$$PATH$$/2980.dat';

--
-- Data for Name: customer_customer_demo; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY customer_customer_demo (customer_id, customer_type_id) FROM stdin;
\.
COPY customer_customer_demo (customer_id, customer_type_id) FROM '$$PATH$$/2981.dat';

--
-- Data for Name: customer_demographics; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY customer_demographics (customer_type_id, customer_desc) FROM stdin;
\.
COPY customer_demographics (customer_type_id, customer_desc) FROM '$$PATH$$/2982.dat';

--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY customers (customer_id, company_name, contact_name, contact_title, address, city, region, postal_code, country, phone, fax) FROM stdin;
\.
COPY customers (customer_id, company_name, contact_name, contact_title, address, city, region, postal_code, country, phone, fax) FROM '$$PATH$$/2983.dat';

--
-- Data for Name: detail_pinjam; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY detail_pinjam (id_detail_pinjam, id_inventaris, jumlah) FROM stdin;
\.
COPY detail_pinjam (id_detail_pinjam, id_inventaris, jumlah) FROM '$$PATH$$/2969.dat';

--
-- Data for Name: employee_territories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY employee_territories (employee_id, territory_id) FROM stdin;
\.
COPY employee_territories (employee_id, territory_id) FROM '$$PATH$$/2985.dat';

--
-- Data for Name: employees; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY employees (employee_id, last_name, first_name, title, title_of_courtesy, birth_date, hire_date, address, city, region, postal_code, country, home_phone, extension, photo, notes, reports_to, photo_path) FROM stdin;
\.
COPY employees (employee_id, last_name, first_name, title, title_of_courtesy, birth_date, hire_date, address, city, region, postal_code, country, home_phone, extension, photo, notes, reports_to, photo_path) FROM '$$PATH$$/2984.dat';

--
-- Data for Name: inventaris; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY inventaris (id_inventaris, nama, kondisi, keterangan, jumlah, id_jenis, tanggal_register, id_ruang, kode_inventaris, id_petugas) FROM stdin;
\.
COPY inventaris (id_inventaris, nama, kondisi, keterangan, jumlah, id_jenis, tanggal_register, id_ruang, kode_inventaris, id_petugas) FROM '$$PATH$$/2971.dat';

--
-- Data for Name: jenis; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY jenis (id_jenis, nama_jenis, kode_jenis, keterangan) FROM stdin;
\.
COPY jenis (id_jenis, nama_jenis, kode_jenis, keterangan) FROM '$$PATH$$/2973.dat';

--
-- Data for Name: order_details; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY order_details (order_id, product_id, unit_price, quantity, discount) FROM stdin;
\.
COPY order_details (order_id, product_id, unit_price, quantity, discount) FROM '$$PATH$$/2986.dat';

--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY orders (order_id, customer_id, employee_id, order_date, required_date, shipped_date, ship_via, freight, ship_name, ship_address, ship_city, ship_region, ship_postal_code, ship_country) FROM stdin;
\.
COPY orders (order_id, customer_id, employee_id, order_date, required_date, shipped_date, ship_via, freight, ship_name, ship_address, ship_city, ship_region, ship_postal_code, ship_country) FROM '$$PATH$$/2987.dat';

--
-- Data for Name: pegawai; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY pegawai (id_pegawai, nama_pegawai, nip, alamat) FROM stdin;
\.
COPY pegawai (id_pegawai, nama_pegawai, nip, alamat) FROM '$$PATH$$/2965.dat';

--
-- Data for Name: peminjaman; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY peminjaman (id_peminjaman, tanggal_pinjam, tanggal_kembali, status_peminjaman, id_pegawai) FROM stdin;
\.
COPY peminjaman (id_peminjaman, tanggal_pinjam, tanggal_kembali, status_peminjaman, id_pegawai) FROM '$$PATH$$/2967.dat';

--
-- Data for Name: petugas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY petugas (id_petugas, username, password, nama_petugas, id_level) FROM stdin;
\.
COPY petugas (id_petugas, username, password, nama_petugas, id_level) FROM '$$PATH$$/2977.dat';

--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY products (product_id, product_name, supplier_id, category_id, quantity_per_unit, unit_price, units_in_stock, units_on_order, reorder_level, discontinued) FROM stdin;
\.
COPY products (product_id, product_name, supplier_id, category_id, quantity_per_unit, unit_price, units_in_stock, units_on_order, reorder_level, discontinued) FROM '$$PATH$$/2988.dat';

--
-- Data for Name: region; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY region (region_id, region_description) FROM stdin;
\.
COPY region (region_id, region_description) FROM '$$PATH$$/2989.dat';

--
-- Data for Name: ruang; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY ruang (id_ruang, nama_ruang, kode_ruang, keterangan) FROM stdin;
\.
COPY ruang (id_ruang, nama_ruang, kode_ruang, keterangan) FROM '$$PATH$$/2975.dat';

--
-- Data for Name: shippers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY shippers (shipper_id, company_name, phone) FROM stdin;
\.
COPY shippers (shipper_id, company_name, phone) FROM '$$PATH$$/2990.dat';

--
-- Data for Name: suppliers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY suppliers (supplier_id, company_name, contact_name, contact_title, address, city, region, postal_code, country, phone, fax, homepage) FROM stdin;
\.
COPY suppliers (supplier_id, company_name, contact_name, contact_title, address, city, region, postal_code, country, phone, fax, homepage) FROM '$$PATH$$/2991.dat';

--
-- Data for Name: tb_level; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_level (id_level, nama_level) FROM stdin;
\.
COPY tb_level (id_level, nama_level) FROM '$$PATH$$/2979.dat';

--
-- Data for Name: territories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY territories (territory_id, territory_description, region_id) FROM stdin;
\.
COPY territories (territory_id, territory_description, region_id) FROM '$$PATH$$/2992.dat';

--
-- Data for Name: us_states; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY us_states (state_id, state_name, state_abbr, state_region) FROM stdin;
\.
COPY us_states (state_id, state_name, state_abbr, state_region) FROM '$$PATH$$/2993.dat';

--
-- Name: detail_pinjam_id_detail_pinjam_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('detail_pinjam_id_detail_pinjam_seq', 1, false);


--
-- Name: inventaris_id_inventaris_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('inventaris_id_inventaris_seq', 1, false);


--
-- Name: jenis_id_jenis_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('jenis_id_jenis_seq', 1, false);


--
-- Name: pegawai_id_pegawai_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('pegawai_id_pegawai_seq', 1, false);


--
-- Name: peminjaman_id_peminjaman_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('peminjaman_id_peminjaman_seq', 1, false);


--
-- Name: petugas_id_petugas_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('petugas_id_petugas_seq', 1, false);


--
-- Name: ruang_id_ruang_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('ruang_id_ruang_seq', 1, false);


--
-- Name: tb_level_id_level_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('tb_level_id_level_seq', 1, false);


--
-- Name: detail_pinjam detail_pinjam_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY detail_pinjam
    ADD CONSTRAINT detail_pinjam_pkey PRIMARY KEY (id_detail_pinjam);


--
-- Name: inventaris inventaris_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY inventaris
    ADD CONSTRAINT inventaris_pkey PRIMARY KEY (id_inventaris);


--
-- Name: jenis jenis_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY jenis
    ADD CONSTRAINT jenis_pkey PRIMARY KEY (id_jenis);


--
-- Name: pegawai pegawai_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY pegawai
    ADD CONSTRAINT pegawai_pkey PRIMARY KEY (id_pegawai);


--
-- Name: peminjaman peminjaman_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY peminjaman
    ADD CONSTRAINT peminjaman_pkey PRIMARY KEY (id_peminjaman);


--
-- Name: petugas petugas_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY petugas
    ADD CONSTRAINT petugas_pkey PRIMARY KEY (id_petugas);


--
-- Name: categories pk_categories; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY categories
    ADD CONSTRAINT pk_categories PRIMARY KEY (category_id);


--
-- Name: customer_customer_demo pk_customer_customer_demo; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY customer_customer_demo
    ADD CONSTRAINT pk_customer_customer_demo PRIMARY KEY (customer_id, customer_type_id);


--
-- Name: customer_demographics pk_customer_demographics; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY customer_demographics
    ADD CONSTRAINT pk_customer_demographics PRIMARY KEY (customer_type_id);


--
-- Name: customers pk_customers; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY customers
    ADD CONSTRAINT pk_customers PRIMARY KEY (customer_id);


--
-- Name: employee_territories pk_employee_territories; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY employee_territories
    ADD CONSTRAINT pk_employee_territories PRIMARY KEY (employee_id, territory_id);


--
-- Name: employees pk_employees; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY employees
    ADD CONSTRAINT pk_employees PRIMARY KEY (employee_id);


--
-- Name: order_details pk_order_details; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY order_details
    ADD CONSTRAINT pk_order_details PRIMARY KEY (order_id, product_id);


--
-- Name: orders pk_orders; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY orders
    ADD CONSTRAINT pk_orders PRIMARY KEY (order_id);


--
-- Name: products pk_products; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY products
    ADD CONSTRAINT pk_products PRIMARY KEY (product_id);


--
-- Name: region pk_region; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY region
    ADD CONSTRAINT pk_region PRIMARY KEY (region_id);


--
-- Name: shippers pk_shippers; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY shippers
    ADD CONSTRAINT pk_shippers PRIMARY KEY (shipper_id);


--
-- Name: suppliers pk_suppliers; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY suppliers
    ADD CONSTRAINT pk_suppliers PRIMARY KEY (supplier_id);


--
-- Name: territories pk_territories; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY territories
    ADD CONSTRAINT pk_territories PRIMARY KEY (territory_id);


--
-- Name: us_states pk_usstates; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY us_states
    ADD CONSTRAINT pk_usstates PRIMARY KEY (state_id);


--
-- Name: ruang ruang_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ruang
    ADD CONSTRAINT ruang_pkey PRIMARY KEY (id_ruang);


--
-- Name: tb_level tb_level_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_level
    ADD CONSTRAINT tb_level_pkey PRIMARY KEY (id_level);


--
-- Name: customer_customer_demo fk_customer_customer_demo_customer_demographics; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY customer_customer_demo
    ADD CONSTRAINT fk_customer_customer_demo_customer_demographics FOREIGN KEY (customer_type_id) REFERENCES customer_demographics(customer_type_id);


--
-- Name: customer_customer_demo fk_customer_customer_demo_customers; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY customer_customer_demo
    ADD CONSTRAINT fk_customer_customer_demo_customers FOREIGN KEY (customer_id) REFERENCES customers(customer_id);


--
-- Name: employee_territories fk_employee_territories_employees; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY employee_territories
    ADD CONSTRAINT fk_employee_territories_employees FOREIGN KEY (employee_id) REFERENCES employees(employee_id);


--
-- Name: employee_territories fk_employee_territories_territories; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY employee_territories
    ADD CONSTRAINT fk_employee_territories_territories FOREIGN KEY (territory_id) REFERENCES territories(territory_id);


--
-- Name: employees fk_employees_employees; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY employees
    ADD CONSTRAINT fk_employees_employees FOREIGN KEY (reports_to) REFERENCES employees(employee_id);


--
-- Name: order_details fk_order_details_orders; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY order_details
    ADD CONSTRAINT fk_order_details_orders FOREIGN KEY (order_id) REFERENCES orders(order_id);


--
-- Name: order_details fk_order_details_products; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY order_details
    ADD CONSTRAINT fk_order_details_products FOREIGN KEY (product_id) REFERENCES products(product_id);


--
-- Name: orders fk_orders_customers; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY orders
    ADD CONSTRAINT fk_orders_customers FOREIGN KEY (customer_id) REFERENCES customers(customer_id);


--
-- Name: orders fk_orders_employees; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY orders
    ADD CONSTRAINT fk_orders_employees FOREIGN KEY (employee_id) REFERENCES employees(employee_id);


--
-- Name: orders fk_orders_shippers; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY orders
    ADD CONSTRAINT fk_orders_shippers FOREIGN KEY (ship_via) REFERENCES shippers(shipper_id);


--
-- Name: products fk_products_categories; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY products
    ADD CONSTRAINT fk_products_categories FOREIGN KEY (category_id) REFERENCES categories(category_id);


--
-- Name: products fk_products_suppliers; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY products
    ADD CONSTRAINT fk_products_suppliers FOREIGN KEY (supplier_id) REFERENCES suppliers(supplier_id);


--
-- Name: territories fk_territories_region; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY territories
    ADD CONSTRAINT fk_territories_region FOREIGN KEY (region_id) REFERENCES region(region_id);


--
-- PostgreSQL database dump complete
--

